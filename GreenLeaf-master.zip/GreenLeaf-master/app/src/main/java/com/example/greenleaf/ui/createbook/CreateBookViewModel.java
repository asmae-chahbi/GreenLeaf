package com.example.greenleaf.ui.createbook;

import androidx.lifecycle.ViewModel;

public class CreateBookViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
